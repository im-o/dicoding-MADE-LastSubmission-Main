package com.stimednp.aplikasimoviecataloguesub4.addingmethod;

/**
 * Created by rivaldy on 8/18/2019.
 */

public class Constant {
    public static final String API_KEY = "8b904530a7aced766995fa063ed27355";
}
