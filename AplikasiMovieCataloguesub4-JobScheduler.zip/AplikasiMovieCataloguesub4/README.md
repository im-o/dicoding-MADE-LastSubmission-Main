**This is the rule of this submission :**  
- Menggunakan library pihak ketiga seperti Retrofit, Fast Android Networking, dsb.
- Menggunakan library penyimpanan lokal pihak ketiga seperti Room, Realm, dsb.
- Menerapkan design pattern seperti MVP, MVVM, Arch Component, dsb.
- Aplikasi bisa memberikan pesan eror jika data tidak berhasil ditampilkan.
- Menuliskan kode dengan bersih.  

Submission by [Dicoding](https://www.dicoding.com)
